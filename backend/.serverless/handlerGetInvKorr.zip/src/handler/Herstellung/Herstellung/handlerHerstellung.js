"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.handlerHerstellung = void 0;
const dbclient_1 = require("../../../db/dbclient");
const Errors = __importStar(require("../../../error/errors"));
const validate_1 = require("../../../validation/validate");
const handlerHerstellung = async (event) => {
    let connection;
    const { Rezept: { Name, RezeptID, BehaelterID, DeckelID, MatID, Menge, Materialien = [] }, } = event.validatedBody;
    let mats = [];
    try {
        connection = await (0, dbclient_1.getConnection)();
        await connection.beginTransaction();
        if (Name === "Kerze") {
            const [behaelterrows] = await connection.query(`SELECT MatID AS BehaelterMatID FROM behaelter WHERE BehaelterID = ?`, [BehaelterID]);
            const [deckelrows] = await connection.query(`SELECT MatID AS DeckelMatID FROM deckel WHERE DeckelID = ?`, [DeckelID]);
            // Base mats
            mats.push({ MatID, Menge }, { MatID: parseInt(behaelterrows[0].BehaelterMatID), Menge }, { MatID: parseInt(deckelrows[0].DeckelMatID), Menge });
            for (const m of Materialien) {
                mats.push(m);
            }
            for (const row of mats) {
                await connection.query(`UPDATE materiallager SET Menge = Menge - COALESCE(?, 0) WHERE MatID = ?`, [row.Menge, row.MatID]);
            }
        }
        else if (Name === "SprayDiff") {
            // Logik für SprayDiff hier rein, wenn gebraucht
        }
        else if (Name === "ZP") {
            // Logik für ZP hier rein, wenn gebraucht
        }
        await connection.commit();
        const resultData = {
            Herstellung: {
                success: true,
                message: `Herstellung für Rezept "${Name}" erfolgreich verarbeitet.`,
                verwendeteMaterialien: mats,
            },
        };
        const validated = (0, validate_1.validateData)("herstellenSchema", resultData);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Herstellung erfolgreich abgeschlossen",
                data: validated,
            }),
        };
    }
    catch (error) {
        if (connection)
            await connection.rollback();
        return Errors.handleError(error, "handlerHerstellung");
    }
    finally {
        if (connection)
            connection.release();
        await (0, dbclient_1.closePool)();
    }
};
exports.handlerHerstellung = handlerHerstellung;
//# sourceMappingURL=handlerHerstellung.js.map